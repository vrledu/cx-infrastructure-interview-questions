import boto3
import logging
import os

# logging
LOG_LEVEL = os.environ.get("LOG_LEVEL", logging.INFO)
root_logger = logging.getLogger()
root_logger.setLevel(LOG_LEVEL)
log = logging.getLogger(__name__)


def get_client(region):
    log.debug("Getting DynamoDB Client")
    client = boto3.client("dynamodb", region_name=region)
    return client


def get_table_region():
    log.debug("Getting Table Region")
    return os.environ.get("TABLE_REGION")


def get_table_name():
    log.debug("Getting Table Name")
    return os.environ.get("TABLE_NAME")


def extract_phone_number(event):
    phone_number = event['Details']['ContactData']['CustomerEndpoint']['Address']
    log.info(f"Phone number to query db: {phone_number}")
    return phone_number


def get_item(dbb_client, table_name, phone_number):
    response = dbb_client.get_item(
        TableName=table_name,
        Key={"PhoneNumber": {"S": phone_number}}
    )
    log.info(f"Raw response from dynamodb get: {response}")
    return response


def parse_response(data):
    customer_information = {}
    item = data["Item"]
    for k, v in item.items():
        for key, value in v.items():
            customer_information[k] = value
    log.info(f"Customer information parsed {customer_information}")
    return customer_information


def get_customer_information(event):
    log.info("Started get_customer_information")
    table_name: str = get_table_name()
    table_region: str = get_table_region()
    dbb_client = get_client(table_region)
    phone_number: str = extract_phone_number(event)
    log.info(f"Using dynamodb table: {table_name} in region: {table_region} to request data for {phone_number}")
    response = get_item(dbb_client, table_name, phone_number)
    return parse_response(response)


def check_if_event_is_warming(event):
    try:
        return event["detail-type"] == "Scheduled Event"
    except KeyError:
        return False


def lambda_handler(event, context):
    log.info(f"Event received by Lambda: {event}")

    if check_if_event_is_warming(event):
        log.info("WARMING EVENT")
        return event
    else:
        try:
            return get_customer_information(event)
        except Exception as e:
            log.error(f"An error occured: {e}")
            return {"CustomerRecord": False}
